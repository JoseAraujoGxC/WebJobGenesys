﻿namespace WebJobGxCGenesys.Models
{
    public class PrimaryContactInfo {
        public string display { get; set; }
        public string mediaType { get; set; }
        public string type { get; set; }
        public string extension { get; set; }
        public string address { get; set; }
    }
}

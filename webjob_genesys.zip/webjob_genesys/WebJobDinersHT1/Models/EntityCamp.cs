﻿using System;

namespace WebJobGxCGenesys.Models {
    public class EntityCamp {
        public string id { get; set; }
        public string name { get; set; }
        public DateTime dateCreated { get; set; }

    }

}

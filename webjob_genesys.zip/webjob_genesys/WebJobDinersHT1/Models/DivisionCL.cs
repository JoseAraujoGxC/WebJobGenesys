﻿namespace WebJobGxCGenesys.Models {
    public class DivisionCL {
        public string id { get; set; }
        public string name { get; set; }
        public string selfUri { get; set; }
    }

}

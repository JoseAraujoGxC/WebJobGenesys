﻿namespace WebJobGxCGenesys.Models {
    public class Chat {
        public string jabberId { get; set; }
    }

}

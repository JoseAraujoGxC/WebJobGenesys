﻿namespace WebJobGxCGenesys.Models {
    public class PhoneColumnCL {
        public string columnName { get; set; }
        public string type { get; set; }
    }

}

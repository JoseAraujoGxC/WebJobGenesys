﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebJobGxCGenesys.Models {
    public class Image {
        public string resolution { get; set; }
        public string imageUri { get; set; }
    }

}

﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using WebJobGxCGenesys.Models;

namespace WebJobDinersHT1
{
    public class Program {
        
        public static string connectionString = "Server=tcp:104.44.140.207,1433;Initial Catalog=Genesys;Persist Security Info=False;User ID=htcuser;Password=HT2022cu..;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        public static string connectionString1 = "Server=tcp:104.44.140.207,1433;Initial Catalog=Genesys;Persist Security Info=False;User ID=htcuser;Password=HT2022cu..;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
        //public static string connectionString = "Data Source=127.17.0.1, 1460;Initial Catalog=Genesys;User Id=sa;Password=saPwd2022*;MultipleActiveResultSets=true;Encrypt=False";
        //public static string connectionString1 = "Data Source=127.17.0.1, 1460;Initial Catalog=Genesys;User Id=sa;Password=saPwd2022*;MultipleActiveResultSets=true;Encrypt=False";

        public string strToken = "";
        public string inicio_proceso = "";
        public string fin_proceso = "";
        public string fecha_proceso = "";
        public string intervaloG = "";
       
        //Datos Oatuh GxC
        public static string clientId = "b35769b9-e2df-4138-a94d-01e76856dac9";
        public static string secretClientId = "ocMuH7ZnlR19rBrZq96A5MvgXW8qZbJC8Pe2EmhW7jY";
        public static string accessToken = "";
        // Please set the following connection strings in app.config for this WebJob to run:
        // AzureWebJobsDashboard and AzureWebJobsStorage
        static void Main() {
            //InitializeHangFire();
            getToken();
            DetalleInteracciones(); //carga detalle interacciones

        }

        public static void getToken() {

            //Datos GxC DESARROLLO
            clientId = "e02d545c-df14-41fb-9032-7bc7822c23db";
            secretClientId = "oOqMW-qlevJ6RqLIqgvduyKyBJbCTnZ7mRfBu67oOII";

            //Datos GxC PRUEBAS
            clientId = "ced37f32-0d09-4b6b-a4e8-a8f6db876477";
            secretClientId = "zg8cnYVzkXJ39g5peDdlN_-Wq3F4Dxua5l9SfsQ2n7I";

            try {

                TokenPurecloud tempResponse = null;
                RestClient client011 = null;
                RestRequest request = null;
                IRestResponse response = null;
                while (tempResponse == null || tempResponse.access_token == "undefined" || tempResponse.access_token == null) {
                    client011 = new RestClient("https://login.usw2.pure.cloud/oauth/token?grant_type=client_credentials&client_id=" + clientId + "&client_secret=" + secretClientId);
                    client011.Timeout = -1;
                    request = new RestRequest(Method.POST);
                    request.AddHeader("Host", "login.usw2.pure.cloud");
                    request.AddHeader("Content-Type", "application/json");
                    request.AddHeader("Authorization", "Basic BASE64(" + clientId + ":" + secretClientId + ")");
                    request.JsonSerializer = new JsonDotNetSerializer();
                    response = client011.Execute(request);
                    tempResponse = JsonConvert.DeserializeObject<TokenPurecloud>(response.Content);
                }

                accessToken = tempResponse.access_token;

            } catch (Exception ee) {
                Console.WriteLine("Si existe: " + ee.Message);
                throw;
            }
        }//fin getToken

        public static void DetalleInteracciones() {

            string jsonnewstedUU = "";
            Dictionary<string, string> IDAgentes = new Dictionary<string, string>();
            Dictionary<string, string> IDContactList = new Dictionary<string, string>();

            string URLRestAPI = "https://api." + "usw2.pure.cloud" + "/api/v2/users";

            double paginasA = 1;
            for (int ii = 1; ii <= paginasA; ii++) {

                URLRestAPI = "https://api.usw2.pure.cloud/api/v2/users?pageSize=100&pageNumber=" + ii;
                jsonnewstedUU = @"{'pageSize': 100,'pageNumber': '" + ii + "'}";

                var jsonsUU = JsonConvert.DeserializeObject(jsonnewstedUU);
                var clientU = new RestSharp.RestClient(URLRestAPI);
                var requestUU = new RestSharp.RestRequest(RestSharp.Method.GET);
                requestUU.RequestFormat = RestSharp.DataFormat.Json;
                requestUU.AddHeader("Content-Type", "application/json");
                requestUU.AddHeader("Host", "api.usw2.pure.cloud");
                requestUU.AddHeader("Authorization", "Bearer " + accessToken);
                requestUU.AddParameter("application/json", jsonsUU, ParameterType.RequestBody);
                IRestResponse responseUU = clientU.Execute(requestUU);
                RootObjectUser rootObjUU = JsonConvert.DeserializeObject<RootObjectUser>(responseUU.Content);

                var total = rootObjUU.total;
                double totalHistA = Convert.ToDouble(total);
                paginasA = Math.Round(totalHistA / 100);
                foreach (var item in rootObjUU.entities) {
                    IDAgentes.Add(item.id, item.name);
                }

            }

            //*************************************************************************************************
            URLRestAPI = "https://api." + "usw2.pure.cloud" + "/api/v2/outbound/contactlists/divisionviews?pageSize=100";

            double paginasACL = 1;
            for (int ii = 1; ii <= paginasACL; ii++) {
                URLRestAPI = "https://api.usw2.pure.cloud/api/v2/outbound/contactlists/divisionviews?pageSize=100&pageNumber=" + ii;
                jsonnewstedUU = @"{'pageSize': 100,'pageNumber': '" + ii + "'}";
                var jsonsUU = JsonConvert.DeserializeObject(jsonnewstedUU);
                var clientU = new RestSharp.RestClient(URLRestAPI);
                var requestUU = new RestSharp.RestRequest(RestSharp.Method.GET);
                requestUU.RequestFormat = RestSharp.DataFormat.Json;
                requestUU.AddHeader("Content-Type", "application/json");
                requestUU.AddHeader("Host", "api.usw2.pure.cloud");
                requestUU.AddHeader("Authorization", "Bearer " + accessToken);
                requestUU.AddParameter("application/json", jsonsUU, ParameterType.RequestBody);
                IRestResponse responseUU = clientU.Execute(requestUU);
                RootCL rootObjUUCL = JsonConvert.DeserializeObject<RootCL>(responseUU.Content);

                var total = rootObjUUCL.total;
                double totalHistA = Convert.ToDouble(total);
                paginasACL = Math.Round(totalHistA / 100);

                foreach (var item in rootObjUUCL.entities) {
                    IDContactList.Add(item.id, item.name);
                }

            }
            //*************************************************************************************************/

            //DateTime fecha = DateTime.Now.AddDays(-1);
            DateTime fecha = DateTime.Now;
            //DateTime fecha1 = DateTime.Now;
            DateTime fecha1 = fecha;
            var ffc = fecha.ToString("yyyy-MM-dd");
            var ffn = fecha1.ToString("yyyy-MM-dd");

            //Fecha Inicio
            string anio = ffc.Substring(0, 4);
            string month = ffc.Substring(5, 2);
            string dia = String.Empty;
            /*******************************************************************************/
            int hour = fecha.Hour;
            
            if(hour >= 19 && hour <= 23)
            {
                var _dia = Int32.Parse(ffc.Substring(8, 2)) + 1;
                dia = _dia.ToString();

                int _auxHor = (hour + 5) - 24;
                hour = _auxHor;
            }
            else
            {
                dia = ffc.Substring(8, 2);
                hour += 5;
            }

            string fi = string.Empty;
            /*******************************************************************************/
            //string fi = anio + "-" + month.ToString() + "-" + dia + "T05:00:00.000Z/";
            //fi = anio + "-" + month.ToString() + "-" + dia + "T21:00:00.000Z/";

            //Fecha Fin
            string anio1 = ffn.Substring(0, 4);
            string month1 = ffn.Substring(5, 2);
            string dia1 = String.Empty;
            /*******************************************************************************/
            int hour1 = fecha1.Hour;

            if (hour1 >= 19 && hour1 <= 23)
            {
                var _dia1 = Int32.Parse(ffc.Substring(8, 2)) + 1;
                dia1 = _dia1.ToString();

                int _auxHor = (hour1 + 5) - 24;
                hour1 = _auxHor;
            }
            else
            {
                dia1= ffn.Substring(8, 2);
                hour1 += 5;
            }

            string ff = string.Empty;
            /*******************************************************************************/
            //string ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T05:00:00.000Z";
            //ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T21:30:00.000Z";
            
            if(hour == 0)
            {
                if (fecha1.Minute >= 0 && fecha1.Minute < 30)
                {
                    int _dia = Int32.Parse(dia);
                    fi = anio + "-" + month.ToString() + "-" + (_dia - 1) + "T23:30:00.000Z/";
                    ff = anio1 + "-" + month1.ToString() + "-" + (_dia - 1) + "T23:59:59.999";
                }
            } 
            else
            {
                if (fecha1.Minute >= 0 && fecha1.Minute < 30)
                {
                    fi = anio + "-" + month.ToString() + "-" + dia + "T" + (hour - 1) + ":30:00.000Z/";
                    ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T" + (hour1 - 1) + ":59:59.999";
                }
                else if (fecha1.Minute >= 30 && fecha1.Minute < 60)
                {
                    fi = anio + "-" + month.ToString() + "-" + dia + "T" + hour + ":00:00.000Z/";
                    ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T" + hour1 + ":29:59.999";
                }
            }
            
            
            //fi = anio + "-" + month.ToString() + "-" + dia + "T05:00:00.000Z/";
            //ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T05:00:00.000Z";
            //fi = anio + "-" + month.ToString() + "-" + dia + "T15:30:00.000Z/";
            //ff = anio1 + "-" + month1.ToString() + "-" + dia1 + "T16:00:00.000Z";

            string intervalo = fi + ff;
            double paginasT = 1;
            //FECHA PROCESO
            //string fiP = anio + "-" + month.ToString() + "-" + dia + "T00:00:00.000Z/";
            //string ffP = anio + "-" + month.ToString() + "-" + dia + "T23:59:59.000Z";
            string fiP = fi;
            string ffP = ff;
            //string intervaloProceso = fiP + ffP;
            string intervaloProceso = "2022-08-29T21:30:00.000Z/2022-08-29T22:00:00.000Z";
            for (int ii = 1; ii <= paginasT; ii++) {

                //{ "interval":"2022-08-29T21:30:00.000Z/2022-08-29T22:00:00.000Z","order":"asc","paging":{ "pageSize":100,"pageNumber":"1"} }
                
                string jsonnewsted = @"{
                        'interval': '" + intervalo + "'," +
                        "'order': 'asc','paging': {'pageSize': 100,'pageNumber': '" + ii + "'}}";
                

                Console.WriteLine($"jsonnewsted: {jsonnewsted}");

                URLRestAPI = "https://api." + "usw2.pure.cloud" + "/api/v2/analytics/conversations/details/query";
                var jsons = JsonConvert.DeserializeObject(jsonnewsted);

                var client = new RestClient(URLRestAPI);
                client.Timeout = -1;
                var request1 = new RestRequest(Method.POST);
                request1.RequestFormat = DataFormat.Json;
                request1.AddHeader("Content-Type", "application/json");
                request1.AddHeader("Authorization", "Bearer " + accessToken);
                request1.AddParameter("application/json", jsons, ParameterType.RequestBody);
                IRestResponse response1 = client.Execute(request1);

                Console.WriteLine($"response1: {response1.Content}");

                RootObject rootObj = JsonConvert.DeserializeObject<RootObject>(response1.Content);

                var totalhits = rootObj.totalHits;
                double totalHistD = Convert.ToDouble(totalhits);
                paginasT = Math.Round(totalHistD / 100);
                System.Data.DataTable dt = new System.Data.DataTable();
                if (response1.Content != null) {
                    if (response1.Content.Length > 0) {
                        try {
                            foreach (var item in rootObj.conversations) {
                                foreach (var item2 in item.participants) {
                                    foreach (var item3 in item2.sessions) {
                                        foreach (var item4 in item3.segments) {
                                            SqlParameter[] param = new SqlParameter[24];

                                            DateTime d1 = new DateTime();
                                            DateTime d2 = new DateTime();
                                            d1 = Convert.ToDateTime(item4.segmentStart.ToString("yyyy-MM-dd HH:mm:ss"));
                                            d2 = Convert.ToDateTime(item4.segmentEnd.ToString("yyyy-MM-dd HH:mm:ss"));
                                            var diffInSeconds = (d1 - d2).TotalSeconds;

                                            var nombreusuario = Nonulo(item2.userId);
                                            var nombreusuarioF = IDAgentes.Where(p => p.Key == nombreusuario).FirstOrDefault().Value;
                                            var nombreContactList = Nonulo(item3.outboundContactListId);
                                            var nombreContactListF = IDContactList.Where(p => p.Key == nombreContactList).FirstOrDefault().Value;

                                            param[0]  = new SqlParameter("@numId", 1);
                                            param[1]  = new SqlParameter("@Fechaconsul", intervaloProceso);
                                            param[2]  = new SqlParameter("@conversationId", Nonulo(item.conversationId));
                                            param[3]  = new SqlParameter("@participantId", Nonulo(item2.participantId));
                                            param[4]  = new SqlParameter("@participantName", Nonulo(item2.participantName));
                                            param[5]  = new SqlParameter("@purpose", Nonulo(item2.purpose));
                                            param[6]  = new SqlParameter("@sessionId", Nonulo(item3.sessionId));
                                            param[7]  = new SqlParameter("@direction", Nonulo(item3.direction));
                                            param[8]  = new SqlParameter("@dnis", Nonulo(item3.dnis));
                                            param[9]  = new SqlParameter("@mediaType", Nonulo(item3.mediaType));
                                            param[10] = new SqlParameter("@timeoutSeconds", Nonulo(item3.timeoutSeconds));
                                            param[11] = new SqlParameter("@disconnectType", Nonulo(item4.disconnectType));
                                            param[12] = new SqlParameter("@segmentType", Nonulo(item4.segmentType));
                                            param[13] = new SqlParameter("@segmentStart", Nonulo(item4.segmentStart.ToString("yyyy-MM-dd HH:mm:ss.fff")));
                                            param[14] = new SqlParameter("@segmentEnd", Nonulo(item4.segmentEnd.ToString("yyyy-MM-dd HH:mm:ss.fff")));
                                            param[15] = new SqlParameter("@wrapUpCode", Nonulo(item4.wrapUpCode));
                                            param[16] = new SqlParameter("@userId", Nonulo(item2.userId));
                                            param[17] = new SqlParameter("@queueId", Nonulo(item4.queueId));
                                            param[18] = new SqlParameter("@outboundCampaignId", Nonulo(item3.outboundCampaignId));
                                            param[19] = new SqlParameter("@outboundContactId", Nonulo(item3.outboundContactId));
                                            param[20] = new SqlParameter("@outboundContactListId", Nonulo(nombreContactListF));
                                            param[21] = new SqlParameter("@Segundos", Math.Abs(diffInSeconds));
                                            param[22] = new SqlParameter("@ani", Nonulo(item3.ani));
                                            param[23] = new SqlParameter("@Usuario", Nonulo(nombreusuarioF));
                                            
                                            //IngresaBase(param, "InsertaDetalle");
                                        
                                        }// end foreach segments
                                    }//end foreach sessions
                                }//end foreach participants
                            }//end for each conversations
                        }//end try
                        catch (Exception es) {
                            Console.Write("Exception when calling AnalyticsApi.PostAnalyticsConversationsDetailsQuery: " + es.Message);
                        }
                    } else {
                        Console.Write("No hay datos para procesar.");
                    }
                }
            }
            Console.Write("Proceso Finalizado.");
        }

        public static void IngresaBase(SqlParameter[] param, string store) {

            string conString = "Server=tcp:104.44.140.207,1433;Initial Catalog=Genesys;Persist Security Info=False;User ID=htcuser;Password=HT2022cu..;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;";
            //string conString = "Data Source=127.17.0.1, 1460;Initial Catalog=Genesys;User Id=sa;Password=saPwd2022*;MultipleActiveResultSets=true;Encrypt=False";

            try { 
                using (SqlConnection con = new SqlConnection(conString))
                 {
                    con.Open();
                    using (var command = new SqlCommand(store, con) { CommandType = CommandType.StoredProcedure }) {
                        SqlCommand cmd = new SqlCommand();
                        command.Parameters.AddRange(param);
                        SqlDataReader reader1 = command.ExecuteReader(); ;//command.exe .ExecuteReader();
                                                                          //var dataTable = new System.Data.DataTable();
                                                                          //dataTable.Load(reader1);
                        con.Close();
                    }
                }
            } catch (Exception es) {
                Console.WriteLine("Error:" + es.Message);
            }

        }//fin IngresaBase
        
        public static string Nonulo(object dato) {
            try {

                if (dato == null || dato == "") {
                    return "0";
                } else {
                    return dato.ToString();
                }
            } catch (Exception e) {
                return e + "-  " + dato.ToString();
            }
        }

    }
}
